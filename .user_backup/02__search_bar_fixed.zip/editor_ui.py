import sys
import os
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QSizeGrip, QSplitter, QTextEdit, QDialog,
    QLineEdit, QColorDialog, QComboBox, QToolBar, QMessageBox,
    QInputDialog, QListWidget, QListWidgetItem, QFrame, QScrollArea,
    QPlainTextEdit # Use PlainTextEdit for description if simple text is enough
)
# Make sure pyqtSlot is imported
from PyQt6.QtCore import Qt, QSize, QPoint, pyqtSignal, pyqtSlot
from PyQt6.QtGui import QIcon, QColor, QAction, QFont, QTextCursor, QKeySequence

# Import the custom title bar
from Template.TitleBar import CustomTitleBar
# Import database functions
import database as db

# Dialog for adding Category/Section/Prompt
class ItemDialog(QDialog):
    def __init__(self, title, label, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(350)

        layout = QVBoxLayout()

        self.name_input = QLineEdit()
        layout.addWidget(QLabel(label))
        layout.addWidget(self.name_input)

        button_layout = QHBoxLayout()
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.reject)
        self.save_btn = QPushButton("Save")
        self.save_btn.clicked.connect(self.accept)
        button_layout.addWidget(self.cancel_btn)
        button_layout.addWidget(self.save_btn)

        layout.addLayout(button_layout)
        self.setLayout(layout)

    def get_value(self):
        return self.name_input.text().strip()

# Main window class for the Prompt Editor
class PromptEditorWindow(QMainWindow):
    # Signal to indicate the editor is closing, so the search UI can be reshown
    closing = pyqtSignal()

    def __init__(self):
        super().__init__()

        # Make window frameless
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)

        # Store current selections
        self.current_category_id = None
        self.current_section_id = None
        self.current_prompt_id = None

        # Initialize UI
        self.initUI()
        self.apply_stylesheet()
        self.load_categories() # Load initial data

    # --- ADD THIS METHOD ---
    @pyqtSlot()
    def show_and_activate(self):
        """Safely shows, activates, and raises the editor window."""
        print("DEBUG: PromptEditorWindow.show_and_activate() called")
        self.show()
        self.activateWindow()
        self.raise_()
    # --- END OF ADDED METHOD ---

    def changeEvent(self, event):
        # Update maximize button icon when window state changes
        if event.type() == event.Type.WindowStateChange:
            if hasattr(self, 'title_bar'):
                if self.isMaximized():
                    self.title_bar.btn_maximize.setText("2")
                    self.title_bar.btn_maximize.setToolTip("Restore")
                else:
                    self.title_bar.btn_maximize.setText("1")
                    self.title_bar.btn_maximize.setToolTip("Maximize")
        super().changeEvent(event)

    def initUI(self):
        self.setWindowTitle('Prompt Editor')
        self.setGeometry(100, 100, 1200, 800)
        self.setMinimumSize(800, 600)

        self.container_widget = QWidget()
        self.container_widget.setObjectName("ContainerWidget")
        main_layout = QVBoxLayout(self.container_widget)
        main_layout.setContentsMargins(1, 1, 1, 1)
        main_layout.setSpacing(0)

        self.title_bar = CustomTitleBar(self)
        main_layout.addWidget(self.title_bar)

        content_widget = QWidget()
        content_layout = QHBoxLayout(content_widget)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)

        self.main_splitter = QSplitter(Qt.Orientation.Horizontal)
        self.sidebar_splitter = QSplitter(Qt.Orientation.Horizontal)
        self.sidebar_splitter.setObjectName("SidebarSplitter")

        # ====== Categories Panel ======
        categories_panel = QWidget()
        categories_panel.setObjectName("CategoriesPanel")
        categories_layout = QVBoxLayout(categories_panel)
        categories_layout.setContentsMargins(0, 0, 0, 0)
        categories_layout.setSpacing(0)

        categories_header = QWidget()
        categories_header.setObjectName("PanelHeader")
        categories_header_layout = QHBoxLayout(categories_header)
        categories_header_layout.setContentsMargins(10, 10, 10, 10)
        categories_title = QLabel("Categories")
        categories_title.setObjectName("PanelTitle")
        add_category_btn = QPushButton("+ Add Category")
        add_category_btn.setObjectName("AddButton")
        add_category_btn.clicked.connect(self.add_category)
        categories_header_layout.addWidget(categories_title)
        categories_header_layout.addWidget(add_category_btn, 0, Qt.AlignmentFlag.AlignRight)

        categories_list_widget = QScrollArea()
        categories_list_widget.setWidgetResizable(True)
        categories_list_widget.setObjectName("CategoriesList")
        categories_list_widget.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        categories_list_container = QWidget()
        self.categories_layout = QVBoxLayout(categories_list_container)
        self.categories_layout.setContentsMargins(0, 0, 0, 0)
        self.categories_layout.setSpacing(0)
        self.categories_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        categories_list_widget.setWidget(categories_list_container)

        categories_layout.addWidget(categories_header)
        categories_layout.addWidget(categories_list_widget)

        # ====== Sections Panel ======
        sections_panel = QWidget()
        sections_panel.setObjectName("SectionsPanel")
        sections_layout = QVBoxLayout(sections_panel)
        sections_layout.setContentsMargins(0, 0, 0, 0)
        sections_layout.setSpacing(0)

        sections_header = QWidget()
        sections_header.setObjectName("PanelHeader")
        sections_header_layout = QHBoxLayout(sections_header)
        sections_header_layout.setContentsMargins(10, 10, 10, 10)
        self.sections_title = QLabel("Select Category")
        self.sections_title.setObjectName("PanelTitle")
        add_section_btn = QPushButton("+ Add Section")
        add_section_btn.setObjectName("AddButton")
        add_section_btn.clicked.connect(self.add_section)
        sections_header_layout.addWidget(self.sections_title)
        sections_header_layout.addWidget(add_section_btn, 0, Qt.AlignmentFlag.AlignRight)

        sections_list_widget = QScrollArea()
        sections_list_widget.setWidgetResizable(True)
        sections_list_widget.setObjectName("SectionsList")
        sections_list_widget.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        sections_list_container = QWidget()
        self.sections_layout = QVBoxLayout(sections_list_container)
        self.sections_layout.setContentsMargins(0, 0, 0, 0)
        self.sections_layout.setSpacing(0)
        self.sections_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        sections_list_widget.setWidget(sections_list_container)

        sections_layout.addWidget(sections_header)
        sections_layout.addWidget(sections_list_widget)

        # ====== Prompts Panel ======
        prompts_panel = QWidget()
        prompts_panel.setObjectName("PromptsPanel")
        prompts_layout = QVBoxLayout(prompts_panel)
        prompts_layout.setContentsMargins(0, 0, 0, 0)
        prompts_layout.setSpacing(0)

        prompts_header = QWidget()
        prompts_header.setObjectName("PanelHeader")
        prompts_header_layout = QHBoxLayout(prompts_header)
        prompts_header_layout.setContentsMargins(10, 10, 10, 10)
        self.prompts_title = QLabel("Select Section")
        self.prompts_title.setObjectName("PanelTitle")
        add_prompt_btn = QPushButton("+ Add Prompt")
        add_prompt_btn.setObjectName("AddButton")
        add_prompt_btn.clicked.connect(self.add_prompt)
        prompts_header_layout.addWidget(self.prompts_title)
        prompts_header_layout.addWidget(add_prompt_btn, 0, Qt.AlignmentFlag.AlignRight)

        prompts_list_widget = QScrollArea()
        prompts_list_widget.setWidgetResizable(True)
        prompts_list_widget.setObjectName("PromptsList")
        prompts_list_widget.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        prompts_list_container = QWidget()
        self.prompts_layout = QVBoxLayout(prompts_list_container)
        self.prompts_layout.setContentsMargins(0, 0, 0, 0)
        self.prompts_layout.setSpacing(0)
        self.prompts_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        prompts_list_widget.setWidget(prompts_list_container)

        prompts_layout.addWidget(prompts_header)
        prompts_layout.addWidget(prompts_list_widget)

        self.sidebar_splitter.addWidget(categories_panel)
        self.sidebar_splitter.addWidget(sections_panel)
        self.sidebar_splitter.addWidget(prompts_panel)
        self.sidebar_splitter.setSizes([250, 250, 250])

        # ====== Editor Area ======
        main_area = QWidget()
        main_area.setObjectName("MainArea")
        main_area_layout = QVBoxLayout(main_area)
        main_area_layout.setContentsMargins(10, 10, 10, 10)
        main_area_layout.setSpacing(5)

        # Editor toolbar (simplified, remove search for now)
        toolbar = QWidget()
        toolbar_layout = QHBoxLayout(toolbar)
        toolbar_layout.setContentsMargins(0, 0, 0, 0)
        self.toggle_sidebar_btn = QPushButton("◀")
        self.toggle_sidebar_btn.setObjectName("ToggleSidebarButton")
        self.toggle_sidebar_btn.setToolTip("Toggle Sidebar")
        self.toggle_sidebar_btn.setFixedSize(30, 30)
        self.toggle_sidebar_btn.clicked.connect(self.toggle_sidebar)
        toolbar_layout.addWidget(self.toggle_sidebar_btn)
        toolbar_layout.addStretch(1)
        # Add Delete button for current prompt
        self.delete_prompt_btn = QPushButton("Delete Prompt")
        self.delete_prompt_btn.setObjectName("DeleteButton")
        self.delete_prompt_btn.clicked.connect(self.delete_current_prompt)
        self.delete_prompt_btn.setEnabled(False) # Disable initially
        toolbar_layout.addWidget(self.delete_prompt_btn)


        # Prompt Title Input
        self.prompt_title_input = QLineEdit()
        self.prompt_title_input.setPlaceholderText("Prompt Title")
        self.prompt_title_input.setObjectName("PromptTitleInput")
        self.prompt_title_input.setEnabled(False)
        self.prompt_title_input.editingFinished.connect(self.save_current_prompt_details)

        # Prompt Description Input
        self.prompt_description_input = QPlainTextEdit() # Use PlainTextEdit for multi-line simple text
        self.prompt_description_input.setPlaceholderText("Prompt Description (optional)")
        self.prompt_description_input.setObjectName("PromptDescriptionInput")
        self.prompt_description_input.setFixedHeight(60) # Adjust height as needed
        self.prompt_description_input.setEnabled(False)
        self.prompt_description_input.textChanged.connect(self.save_current_prompt_details)


        # Text formatting toolbar (optional, keep if needed)
        format_toolbar = QToolBar()
        format_toolbar.setObjectName("FormatToolbar")
        bold_action = QAction("B", self)
        bold_action.setToolTip("Bold")
        bold_action.triggered.connect(lambda: self.format_text("bold"))
        format_toolbar.addAction(bold_action)
        italic_action = QAction("I", self)
        italic_action.setToolTip("Italic")
        italic_action.triggered.connect(lambda: self.format_text("italic"))
        format_toolbar.addAction(italic_action)
        underline_action = QAction("U", self)
        underline_action.setToolTip("Underline")
        underline_action.triggered.connect(lambda: self.format_text("underline"))
        format_toolbar.addAction(underline_action)

        # Prompt Content Editor widget
        self.editor = QTextEdit()
        self.editor.setPlaceholderText("Select a prompt to view/edit its content...")
        self.editor.setObjectName("PromptContentEditor")
        self.editor.setEnabled(False)
        self.editor.textChanged.connect(self.save_current_prompt_content) # Separate save for content

        main_area_layout.addWidget(toolbar)
        main_area_layout.addWidget(QLabel("Title:"))
        main_area_layout.addWidget(self.prompt_title_input)
        main_area_layout.addWidget(QLabel("Description:"))
        main_area_layout.addWidget(self.prompt_description_input)
        main_area_layout.addWidget(QLabel("Content:"))
        # main_area_layout.addWidget(format_toolbar) # Optional formatting toolbar
        main_area_layout.addWidget(self.editor)

        self.main_splitter.addWidget(self.sidebar_splitter)
        self.main_splitter.addWidget(main_area)
        self.main_splitter.setSizes([750, 450])

        content_layout.addWidget(self.main_splitter)
        main_layout.addWidget(content_widget)

        sizegrip = QSizeGrip(self.container_widget)
        main_layout.addWidget(sizegrip, 0, Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignRight)
        sizegrip.raise_()

        self.setCentralWidget(self.container_widget)
        self.setup_shortcuts()


    def toggle_sidebar(self):
        current_sizes = self.main_splitter.sizes()
        if current_sizes[0] > 0:
            self.sidebar_sizes = current_sizes[0]
            self.main_splitter.setSizes([0, sum(current_sizes)])
            self.toggle_sidebar_btn.setText("▶")
        else:
            sidebar_size = getattr(self, 'sidebar_sizes', 750)
            self.main_splitter.setSizes([sidebar_size, current_sizes[1]])
            self.toggle_sidebar_btn.setText("◀")

    def apply_stylesheet(self):
        # Using a simplified version of the original stylesheet
        # Add/modify styles as needed
        self.setStyleSheet("""
            #ContainerWidget { background-color: #191a1f; border: 1px solid #464766; }
            QWidget { background-color: transparent; color: #b3b0ad; font-family: 'Segoe UI', Arial; font-size: 10pt; }
            #CustomTitleBar { background-color: #25262b; border-bottom: 1px solid #464766; }
            #SidebarSplitter::handle { background-color: #464766; width: 1px; }
            #CategoriesPanel, #SectionsPanel, #PromptsPanel { background-color: #25262b; border: none; }
            #PanelHeader { background-color: #25262b; border-bottom: 1px solid #464766; }
            #CategoriesList, #SectionsList, #PromptsList { background-color: #25262b; border: none; }
            #PanelTitle { font-weight: bold; font-size: 11pt; }
            #ToggleSidebarButton, #DeleteButton { background-color: transparent; color: #b3b0ad; border: 1px solid #464766; border-radius: 3px; padding: 5px; }
            #ToggleSidebarButton:hover, #DeleteButton:hover { background-color: #464766; }
            #DeleteButton { color: #e74c3c; } /* Red color for delete */
            #DeleteButton:hover { background-color: #c0392b; color: white; }
            #AddButton { background-color: transparent; border: 1px solid #464766; color: #b3b0ad; padding: 5px 8px; border-radius: 3px; text-align: center; }
            #AddButton:hover { background-color: #464766; }
            #MainArea { background-color: #191a1f; }
            #PromptTitleInput, #PromptDescriptionInput, #PromptContentEditor {
                background-color: #1e1e24; border: 1px solid #464766; border-radius: 3px; padding: 5px; color: #b3b0ad;
            }
            #PromptTitleInput:disabled, #PromptDescriptionInput:disabled, #PromptContentEditor:disabled {
                 background-color: #2a2b30; color: #777; border-color: #3a3b40;
            }
            QLabel { color: #888; font-size: 9pt; margin-top: 5px; } /* Labels for inputs */
            QPushButton { background-color: transparent; border: none; padding: 8px 16px; border-radius: 3px; }
            QPushButton:hover { background-color: #464766; }
            QLineEdit { background-color: #1e1e24; border: 1px solid #464766; border-radius: 3px; padding: 5px; }
            QDialog { background-color: #191a1f; color: #b3b0ad; }
            QDialog QLabel { color: #b3b0ad; font-size: 10pt; margin-top: 0px;}
            QDialog QPushButton { border: 1px solid #464766; }
            .ListItemWidget { background-color: transparent; padding: 8px; border: none; border-radius: 3px; }
            .ListItemWidget:hover { background-color: #3a3b40; }
            .ListItemWidget.selected { background-color: #464766; }
            QScrollArea { border: none; }
            QScrollBar:vertical { border: none; background: #25262b; width: 10px; margin: 0px; }
            QScrollBar::handle:vertical { background: #464766; min-height: 20px; border-radius: 5px; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { border: none; background: none; }
        """)

    def _clear_layout(self, layout):
        if layout is not None:
            while layout.count():
                item = layout.takeAt(0)
                widget = item.widget()
                if widget is not None:
                    widget.deleteLater()
                elif item.layout() is not None:
                    self._clear_layout(item.layout())

    def _create_list_item(self, item_id, name, data, click_handler, layout_to_clear=None):
        item_widget = QWidget()
        item_widget.setObjectName(f"item_{item_id}")
        item_widget.setProperty("class", "ListItemWidget")
        item_widget.setProperty("itemId", item_id) # Store ID

        item_layout = QHBoxLayout(item_widget)
        item_layout.setContentsMargins(10, 5, 10, 5)

        name_label = QLabel(name)
        item_layout.addWidget(name_label)
        item_layout.addStretch()

        # Optional: Add delete button per item
        # delete_btn = QPushButton("X")
        # delete_btn.setFixedSize(20, 20)
        # delete_btn.clicked.connect(lambda _, i=item_id: self.delete_item_handler(i, type)) # Need delete handler logic
        # item_layout.addWidget(delete_btn)

        item_widget.mousePressEvent = lambda event, d=data: click_handler(d)

        return item_widget

    # --- Category Loading and Handling ---
    def load_categories(self):
        self._clear_layout(self.categories_layout)
        categories = db.get_categories()
        for category in categories:
            item_widget = self._create_list_item(
                category['id'], category['name'], category, self.category_clicked
            )
            if self.current_category_id == category['id']:
                 item_widget.setProperty("class", "ListItemWidget selected")
            self.categories_layout.addWidget(item_widget)
        self.categories_layout.addStretch() # Push items to top
        # Also clear sections and prompts if no category is selected
        if not self.current_category_id:
            self.load_sections()


    def category_clicked(self, category_data):
        self.current_category_id = category_data['id']
        self.current_section_id = None # Reset section/prompt selection
        self.current_prompt_id = None
        self.sections_title.setText(f"{category_data['name']}")
        self.prompts_title.setText("Select Section")
        self.load_categories() # Reload to update selection highlight
        self.load_sections()
        self.clear_editor_fields()

    def add_category(self):
        dialog = ItemDialog("Add New Category", "Category Name:", self)
        if dialog.exec():
            name = dialog.get_value()
            if name:
                new_id = db.add_category(name)
                if new_id:
                    self.current_category_id = new_id # Select the new one
                    self.load_categories()
                    # Find the newly added category data to simulate click
                    new_category_data = next((c for c in db.get_categories() if c['id'] == new_id), None)
                    if new_category_data:
                        self.category_clicked(new_category_data)
            else:
                 QMessageBox.warning(self, "Input Error", "Category name cannot be empty.")

    # --- Section Loading and Handling ---
    def load_sections(self):
        self._clear_layout(self.sections_layout)
        if self.current_category_id:
            sections = db.get_sections(self.current_category_id)
            for section in sections:
                item_widget = self._create_list_item(
                    section['id'], section['name'], section, self.section_clicked
                )
                if self.current_section_id == section['id']:
                    item_widget.setProperty("class", "ListItemWidget selected")
                self.sections_layout.addWidget(item_widget)
        self.sections_layout.addStretch()
        # Also clear prompts if no section is selected
        if not self.current_section_id:
            self.load_prompts()


    def section_clicked(self, section_data):
        self.current_section_id = section_data['id']
        self.current_prompt_id = None # Reset prompt selection
        self.prompts_title.setText(f"{section_data['name']}")
        self.load_sections() # Reload to update selection highlight
        self.load_prompts()
        self.clear_editor_fields()

    def add_section(self):
        if not self.current_category_id:
            QMessageBox.warning(self, "Warning", "Please select a category first.")
            return
        dialog = ItemDialog("Add New Section", "Section Name:", self)
        if dialog.exec():
            name = dialog.get_value()
            if name:
                new_id = db.add_section(name, self.current_category_id)
                if new_id:
                    self.current_section_id = new_id
                    self.load_sections()
                    # Find the newly added section data to simulate click
                    new_section_data = next((s for s in db.get_sections(self.current_category_id) if s['id'] == new_id), None)
                    if new_section_data:
                        self.section_clicked(new_section_data)
            else:
                 QMessageBox.warning(self, "Input Error", "Section name cannot be empty.")

    # --- Prompt Loading and Handling ---
    def load_prompts(self):
        self._clear_layout(self.prompts_layout)
        if self.current_section_id:
            prompts = db.get_prompts(self.current_section_id)
            for prompt in prompts:
                item_widget = self._create_list_item(
                    prompt['id'], prompt['title'], prompt, self.prompt_clicked
                )
                if self.current_prompt_id == prompt['id']:
                     item_widget.setProperty("class", "ListItemWidget selected")
                self.prompts_layout.addWidget(item_widget)
        self.prompts_layout.addStretch()
        # Clear editor if no prompt selected
        if not self.current_prompt_id:
            self.clear_editor_fields()


    def prompt_clicked(self, prompt_data):
        self.current_prompt_id = prompt_data['id']
        self.load_prompts() # Reload to update selection highlight
        self.load_prompt_details(self.current_prompt_id)

    def add_prompt(self):
        if not self.current_section_id:
            QMessageBox.warning(self, "Warning", "Please select a section first.")
            return
        dialog = ItemDialog("Add New Prompt", "Prompt Title:", self)
        if dialog.exec():
            title = dialog.get_value()
            if title:
                # Add with empty description and content initially
                new_id = db.add_prompt(title, "", "", self.current_section_id)
                if new_id:
                    self.current_prompt_id = new_id
                    self.load_prompts()
                    # Find the newly added prompt data to simulate click
                    new_prompt_data = db.get_prompt(new_id)
                    if new_prompt_data:
                        self.prompt_clicked(new_prompt_data) # Load the new prompt
                    self.prompt_title_input.setFocus() # Focus title field
            else:
                 QMessageBox.warning(self, "Input Error", "Prompt title cannot be empty.")

    def delete_current_prompt(self):
        if not self.current_prompt_id:
            return

        reply = QMessageBox.question(self, 'Confirm Delete',
                                     f"Are you sure you want to delete the prompt '{self.prompt_title_input.text()}'?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                     QMessageBox.StandardButton.No)

        if reply == QMessageBox.StandardButton.Yes:
            db.delete_prompt(self.current_prompt_id)
            self.current_prompt_id = None
            self.load_prompts() # Refresh list
            self.clear_editor_fields()


    # --- Editor Field Handling ---
    def load_prompt_details(self, prompt_id):
        prompt = db.get_prompt(prompt_id)
        if prompt:
            # Block signals temporarily to prevent triggering saves while loading
            self.prompt_title_input.blockSignals(True)
            self.prompt_description_input.blockSignals(True)
            self.editor.blockSignals(True)

            self.prompt_title_input.setText(prompt['title'])
            self.prompt_description_input.setPlainText(prompt['description'] or "")
            self.editor.setHtml(prompt['content'] or "") # Use setHtml if using rich text

            self.prompt_title_input.setEnabled(True)
            self.prompt_description_input.setEnabled(True)
            self.editor.setEnabled(True)
            self.delete_prompt_btn.setEnabled(True)

            self.prompt_title_input.blockSignals(False)
            self.prompt_description_input.blockSignals(False)
            self.editor.blockSignals(False)
        else:
            self.clear_editor_fields()

    def clear_editor_fields(self):
         # Block signals temporarily
        self.prompt_title_input.blockSignals(True)
        self.prompt_description_input.blockSignals(True)
        self.editor.blockSignals(True)

        self.prompt_title_input.clear()
        self.prompt_description_input.clear()
        self.editor.clear()

        self.prompt_title_input.setEnabled(False)
        self.prompt_description_input.setEnabled(False)
        self.editor.setEnabled(False)
        self.delete_prompt_btn.setEnabled(False)

        self.prompt_title_input.blockSignals(False)
        self.prompt_description_input.blockSignals(False)
        self.editor.blockSignals(False)


    def save_current_prompt_details(self):
        """Saves Title and Description."""
        if self.current_prompt_id and self.prompt_title_input.isEnabled():
            title = self.prompt_title_input.text().strip()
            description = self.prompt_description_input.toPlainText().strip()
            # Fetch existing content to avoid overwriting it
            current_prompt = db.get_prompt(self.current_prompt_id)
            if current_prompt:
                content = current_prompt['content']
                if title: # Ensure title is not empty
                    db.update_prompt(self.current_prompt_id, title, description, content)
                    # Refresh the prompt list item in case title changed
                    self.load_prompts()
                else:
                    # Optionally revert or show error if title is cleared
                    QMessageBox.warning(self, "Save Error", "Prompt title cannot be empty.")
                    # Reload original title
                    self.prompt_title_input.blockSignals(True)
                    self.prompt_title_input.setText(current_prompt['title'])
                    self.prompt_title_input.blockSignals(False)


    def save_current_prompt_content(self):
        """Saves only the main Content."""
        if self.current_prompt_id and self.editor.isEnabled():
            content = self.editor.toHtml() # Use toHtml if using rich text
             # Fetch existing title/desc to avoid overwriting them
            current_prompt = db.get_prompt(self.current_prompt_id)
            if current_prompt:
                 db.update_prompt(self.current_prompt_id, current_prompt['title'], current_prompt['description'], content)


    def format_text(self, format_type):
        # Basic rich text formatting (if needed)
        cursor = self.editor.textCursor()
        if not cursor.hasSelection():
            return # Apply only to selection

        text_format = cursor.charFormat()

        if format_type == "bold":
            text_format.setFontWeight(QFont.Weight.Bold if text_format.fontWeight() != QFont.Weight.Bold else QFont.Weight.Normal)
        elif format_type == "italic":
            text_format.setFontItalic(not text_format.fontItalic())
        elif format_type == "underline":
            text_format.setFontUnderline(not text_format.fontUnderline())

        cursor.mergeCharFormat(text_format)
        self.editor.setTextCursor(cursor)
        self.save_current_prompt_content() # Save after formatting


    def setup_shortcuts(self):
        # Add shortcuts if needed, e.g., Ctrl+S to save
        save_shortcut = QAction("Save", self)
        save_shortcut.setShortcut(QKeySequence("Ctrl+S"))
        # Connect to a combined save function if needed, or rely on auto-save
        # save_shortcut.triggered.connect(self.save_current_prompt_details) # Example
        self.addAction(save_shortcut)

        # Add shortcuts for Bold, Italic, Underline
        bold_shortcut = QAction("Bold", self)
        bold_shortcut.setShortcut(QKeySequence("Ctrl+B"))
        bold_shortcut.triggered.connect(lambda: self.format_text("bold"))
        self.addAction(bold_shortcut)

        italic_shortcut = QAction("Italic", self)
        italic_shortcut.setShortcut(QKeySequence("Ctrl+I"))
        italic_shortcut.triggered.connect(lambda: self.format_text("italic"))
        self.addAction(italic_shortcut)

        underline_shortcut = QAction("Underline", self)
        underline_shortcut.setShortcut(QKeySequence("Ctrl+U"))
        underline_shortcut.triggered.connect(lambda: self.format_text("underline"))
        self.addAction(underline_shortcut)


    def closeEvent(self, event):
        # Ensure latest changes are saved (auto-save should handle most)
        # self.save_current_prompt_details() # Call save explicitly if needed
        # self.save_current_prompt_content()
        print("DEBUG: Editor closing")
        self.closing.emit() # Emit signal
        # Hide instead of closing if triggered by title bar 'X'
        self.hide()
        event.ignore() # Ignore the close event to allow hiding


# Example usage (for testing editor independently)
if __name__ == "__main__":
    app = QApplication(sys.argv)
    # Ensure DB is initialized before creating window
    db.initialize_database()
    window = PromptEditorWindow()
    window.show_and_activate() # Use the new method for testing too
    sys.exit(app.exec())