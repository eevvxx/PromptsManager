# This file is assumed to be the same as provided in the original Editor.py context.
# If it's different, please provide the correct content.
# Using a placeholder based on typical CustomTitleBar implementations.

from PyQt6.QtWidgets import QWidget, QHBoxLayout, QPushButton, QLabel, QSizePolicy
from PyQt6.QtCore import Qt, QPoint, QSize
from PyQt6.QtGui import QIcon, QFont

class CustomTitleBar(QWidget):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent_window = parent
        self.setAutoFillBackground(True)
        self.setFixedHeight(35) # Adjust height as needed
        self.setObjectName("CustomTitleBar")

        layout = QHBoxLayout(self)
        layout.setContentsMargins(5, 0, 0, 0) # Left margin for icon, no right margin for buttons
        layout.setSpacing(0)

        # Optional: Window Icon
        self.icon_label = QLabel(self)
        # self.icon_label.setPixmap(parent.windowIcon().pixmap(QSize(16, 16))) # Uncomment if you set a window icon
        self.icon_label.setFixedSize(20, 20)
        self.icon_label.setStyleSheet("margin-left: 5px;") # Space after icon
        layout.addWidget(self.icon_label)

        # Title Label
        self.title_label = QLabel(parent.windowTitle(), self)
        self.title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title_label.setStyleSheet("color: #b3b0ad; margin-left: 5px;") # Style as needed
        layout.addWidget(self.title_label)

        # Spacer to push buttons to the right
        layout.addStretch()

        # --- Window Control Buttons ---
        button_font = QFont("Webdings", 10) # Using Webdings for symbols

        # Minimize Button
        self.btn_minimize = QPushButton("0", self) # Webdings '0' is minimize
        self.btn_minimize.setFont(button_font)
        self.btn_minimize.setFixedSize(40, self.height())
        self.btn_minimize.setObjectName("MinimizeButton")
        self.btn_minimize.setToolTip("Minimize")
        self.btn_minimize.clicked.connect(parent.showMinimized)
        layout.addWidget(self.btn_minimize)

        # Maximize/Restore Button
        self.btn_maximize = QPushButton("1", self) # Webdings '1' is maximize
        self.btn_maximize.setFont(button_font)
        self.btn_maximize.setFixedSize(40, self.height())
        self.btn_maximize.setObjectName("MaximizeButton")
        self.btn_maximize.setToolTip("Maximize")
        self.btn_maximize.clicked.connect(self.toggle_maximize_restore)
        layout.addWidget(self.btn_maximize)

        # Close Button
        self.btn_close = QPushButton("r", self) # Webdings 'r' is close
        self.btn_close.setFont(button_font)
        self.btn_close.setFixedSize(40, self.height())
        self.btn_close.setObjectName("CloseButton")
        self.btn_close.setToolTip("Close")
        self.btn_close.clicked.connect(parent.close)
        layout.addWidget(self.btn_close)

        # Apply Stylesheet for buttons (can be moved to main stylesheet)
        self.setStyleSheet("""
            #CustomTitleBar {
                background-color: #25262b; /* Match editor style */
                border-bottom: 1px solid #464766;
            }
            #MinimizeButton, #MaximizeButton, #CloseButton {
                background-color: transparent;
                border: none;
                color: #b3b0ad;
                padding: 0px;
                margin: 0px;
            }
            #MinimizeButton:hover, #MaximizeButton:hover {
                background-color: #4a4b50; /* Slightly lighter hover */
            }
            #CloseButton:hover {
                background-color: #e81123; /* Red hover for close */
                color: white;
            }
            #MinimizeButton:pressed, #MaximizeButton:pressed, #CloseButton:pressed {
                background-color: #6b6c70;
            }
        """)

        # Variables for dragging
        self._mouse_press_pos = None
        self._mouse_move_pos = None

    def toggle_maximize_restore(self):
        if self.parent_window.isMaximized():
            self.parent_window.showNormal()
            self.btn_maximize.setText("1") # Maximize symbol
            self.btn_maximize.setToolTip("Maximize")
        else:
            self.parent_window.showMaximized()
            self.btn_maximize.setText("2") # Restore symbol
            self.btn_maximize.setToolTip("Restore")

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._mouse_press_pos = event.globalPosition().toPoint()
            self._mouse_move_pos = event.globalPosition().toPoint() - self.parent_window.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.MouseButton.LeftButton and self._mouse_press_pos:
            # Check if it's a drag or just a click intended for buttons
            # Move only if the mouse has moved significantly from the press position
            if (event.globalPosition().toPoint() - self._mouse_press_pos).manhattanLength() > 15: # Threshold
                 # Don't move if maximized
                if not self.parent_window.isMaximized():
                    self.parent_window.move(event.globalPosition().toPoint() - self._mouse_move_pos)
            event.accept()

    def mouseReleaseEvent(self, event):
        self._mouse_press_pos = None
        self._mouse_move_pos = None
        event.accept()

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.toggle_maximize_restore()
        event.accept()

    def setWindowTitle(self, title):
        self.title_label.setText(title)