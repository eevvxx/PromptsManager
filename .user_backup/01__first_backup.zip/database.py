import sqlite3
import os

DATABASE_NAME = 'prompts.db'

def get_db_connection():
    """Establishes a connection to the SQLite database."""
    conn = sqlite3.connect(DATABASE_NAME)
    conn.row_factory = sqlite3.Row # Return rows as dictionary-like objects
    return conn

def initialize_database():
    """Creates the database tables if they don't exist."""
    if os.path.exists(DATABASE_NAME):
        # Basic check if tables exist to avoid re-initialization errors
        # A more robust check might query sqlite_master
        try:
            conn = get_db_connection()
            conn.execute("SELECT id FROM categories LIMIT 1")
            conn.execute("SELECT id FROM sections LIMIT 1")
            conn.execute("SELECT id FROM prompts LIMIT 1")
            conn.close()
            print("Database already initialized.")
            return # Assume already initialized if tables exist
        except sqlite3.OperationalError:
            print("Tables not found, initializing...")
        except Exception as e:
             print(f"Error checking database initialization: {e}")
             # Fall through to initialization if unsure

    print("Initializing database...")
    conn = get_db_connection()
    cursor = conn.cursor()

    # Categories Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE
        )
    ''')

    # Sections Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS sections (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category_id INTEGER NOT NULL,
            FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE CASCADE
        )
    ''')

    # Prompts Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS prompts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            content TEXT NOT NULL,
            section_id INTEGER NOT NULL,
            FOREIGN KEY (section_id) REFERENCES sections (id) ON DELETE CASCADE
        )
    ''')

    conn.commit()
    conn.close()
    print("Database initialized successfully.")

# --- Category Functions ---

def add_category(name):
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO categories (name) VALUES (?)", (name,))
        conn.commit()
        return cursor.lastrowid
    except sqlite3.IntegrityError:
        print(f"Category '{name}' already exists.")
        return None
    finally:
        conn.close()

def get_categories():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM categories ORDER BY name")
    categories = cursor.fetchall()
    conn.close()
    return categories

def update_category(category_id, name):
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("UPDATE categories SET name = ? WHERE id = ?", (name, category_id))
        conn.commit()
    finally:
        conn.close()

def delete_category(category_id):
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM categories WHERE id = ?", (category_id,))
        conn.commit() # Cascading delete should handle sections and prompts
    finally:
        conn.close()

# --- Section Functions ---

def add_section(name, category_id):
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO sections (name, category_id) VALUES (?, ?)", (name, category_id))
        conn.commit()
        return cursor.lastrowid
    finally:
        conn.close()

def get_sections(category_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM sections WHERE category_id = ? ORDER BY name", (category_id,))
    sections = cursor.fetchall()
    conn.close()
    return sections

def update_section(section_id, name):
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("UPDATE sections SET name = ? WHERE id = ?", (name, section_id))
        conn.commit()
    finally:
        conn.close()

def delete_section(section_id):
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM sections WHERE id = ?", (section_id,))
        conn.commit() # Cascading delete should handle prompts
    finally:
        conn.close()

# --- Prompt Functions ---

def add_prompt(title, description, content, section_id):
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO prompts (title, description, content, section_id) VALUES (?, ?, ?, ?)",
                       (title, description, content, section_id))
        conn.commit()
        return cursor.lastrowid
    finally:
        conn.close()

def get_prompts(section_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM prompts WHERE section_id = ? ORDER BY title", (section_id,))
    prompts = cursor.fetchall()
    conn.close()
    return prompts

def get_prompt(prompt_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM prompts WHERE id = ?", (prompt_id,))
    prompt = cursor.fetchone()
    conn.close()
    return prompt

def update_prompt(prompt_id, title, description, content):
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("UPDATE prompts SET title = ?, description = ?, content = ? WHERE id = ?",
                       (title, description, content, prompt_id))
        conn.commit()
    finally:
        conn.close()

def delete_prompt(prompt_id):
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM prompts WHERE id = ?", (prompt_id,))
        conn.commit()
    finally:
        conn.close()

def search_prompts_by_title(search_term):
    """Searches prompts by title and returns detailed info including category and section."""
    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
        SELECT
            p.id AS prompt_id,
            p.title AS prompt_title,
            p.description AS prompt_description,
            p.content AS prompt_content,
            s.name AS section_name,
            c.name AS category_name
        FROM prompts p
        JOIN sections s ON p.section_id = s.id
        JOIN categories c ON s.category_id = c.id
        WHERE p.title LIKE ?
        ORDER BY c.name, s.name, p.title
    """
    # Add wildcards for partial matching
    like_term = f"%{search_term}%"
    cursor.execute(query, (like_term,))
    results = cursor.fetchall()
    conn.close()
    return results

# Initialize the database when the module is imported
if __name__ != "__main__": # Only run initialization if imported
    initialize_database()